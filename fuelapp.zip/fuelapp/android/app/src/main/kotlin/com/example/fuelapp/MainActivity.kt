package com.example.fuelapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
